      use mpi_f08
      implicit none

      type(MPI_Comm) :: comm_out
      type(MPI_Comm) :: comm_in
